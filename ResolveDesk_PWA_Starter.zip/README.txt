ResolveDesk PWA starter

Files:
- index.html: mobile-friendly complaint drafting page
- manifest.webmanifest: installable web-app settings
- service-worker.js: basic offline caching

How to use:
1. Upload these three files to the root of your existing GitHub Pages repository.
2. Keep the repository's Pages setting pointed at the main branch/root.
3. Open the published website in Chrome on Android.
4. Use Chrome menu > Add to Home screen / Install app.

Important:
- This is a progressive web app (PWA), not an APK or Play Store app.
- The current complaint draft is template-based, not AI-generated.
- The ₹45 payment screen is intentionally not connected yet. Razorpay secret keys must never be placed in browser code. Before accepting payment, a secure backend must create orders and verify payment signatures server-side.
- Razorpay account verification/activation must be completed before live payments can be accepted.
